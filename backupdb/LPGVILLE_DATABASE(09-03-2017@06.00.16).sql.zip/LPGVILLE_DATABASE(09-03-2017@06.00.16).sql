--
-- Database : thesis
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `auto_po`
--
DROP TABLE  IF EXISTS `auto_po`;
CREATE TABLE `auto_po` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `OrdersID` varchar(30) NOT NULL,
  `ProductID` varchar(30) NOT NULL,
  `PendingQty` int(11) NOT NULL,
  `Price` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `SupplierID` varchar(30) NOT NULL,
  `DateAdded` date NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `bank`
--
DROP TABLE  IF EXISTS `bank`;
CREATE TABLE `bank` (
  `BankID` int(11) NOT NULL AUTO_INCREMENT,
  `BankName` varchar(60) NOT NULL,
  `AccountName` varchar(60) NOT NULL,
  `AccountNumber` varchar(50) NOT NULL,
  `BankDelete` int(5) NOT NULL,
  PRIMARY KEY (`BankID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `bank`  VALUES ( "2","BDO","LPGVILLE","43412-1233-1231","0");
INSERT INTO `bank`  VALUES ( "3","UCPB","LGPVILLE","2432-2231-3123","0");


--
-- Tabel structure for table `billing_detail`
--
DROP TABLE  IF EXISTS `billing_detail`;
CREATE TABLE `billing_detail` (
  `BillingID` varchar(30) NOT NULL,
  `CustomerName` varchar(100) NOT NULL,
  `Mobile` varchar(20) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `CompleteAddress` varchar(255) NOT NULL,
  `OrdersID` varchar(30) NOT NULL,
  PRIMARY KEY (`BillingID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `billing_detail`  VALUES ( "BILL-18-2","Fritz Tuna","639198240155","fritz_tuna@gmail.com","Caloocan, Metro Manila-Pandacan","ORD-79-2");
INSERT INTO `billing_detail`  VALUES ( "BILL-25-0","Daniel Desario","934 1213","Null","Espana Manila","ORD-48-0");
INSERT INTO `billing_detail`  VALUES ( "BILL-57-1","Fritz Tuna","639198240155","fritz_tuna@gmail.com","Caloocan, Metro Manila-","ORD-36-1");


--
-- Tabel structure for table `business_profile`
--
DROP TABLE  IF EXISTS `business_profile`;
CREATE TABLE `business_profile` (
  `ID` int(5) NOT NULL,
  `BusinessName` varchar(100) NOT NULL,
  `BusinessAddress` varchar(100) NOT NULL,
  `BusinessContact` varchar(30) NOT NULL,
  `BusinessEmail` varchar(50) NOT NULL,
  `BusinessOwner` varchar(70) NOT NULL,
  `TIN` varchar(50) NOT NULL,
  `ORNumber` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `business_profile`  VALUES ( "1","LPGVILLE ","Espana Manila, Philippines","923-3414","lpgville@gmail.com","Katrina Tang","234-234-349-000","234523");


--
-- Tabel structure for table `cancelled_order`
--
DROP TABLE  IF EXISTS `cancelled_order`;
CREATE TABLE `cancelled_order` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `OrdersID` varchar(30) NOT NULL,
  `ReasonID` varchar(30) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `DateCancelled` date NOT NULL,
  `CancelledBy` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `cancelled_order`  VALUES ( "1","ORD-86-1","1","Unlikely","2017-02-25","SUPERADMIN");
INSERT INTO `cancelled_order`  VALUES ( "2","ORD-46-2","3","Well done","2017-02-25","SUPERADMIN");


--
-- Tabel structure for table `cart`
--
DROP TABLE  IF EXISTS `cart`;
CREATE TABLE `cart` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductID` varchar(20) NOT NULL,
  `Qty` int(11) NOT NULL,
  `Price` int(11) NOT NULL,
  `Total` bigint(11) NOT NULL,
  `UserID` varchar(20) NOT NULL,
  `DateCreated` date NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `category`
--
DROP TABLE  IF EXISTS `category`;
CREATE TABLE `category` (
  `CategoryID` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(50) NOT NULL,
  `CategoryReturned` int(5) NOT NULL,
  `CategoryDelete` int(5) NOT NULL,
  PRIMARY KEY (`CategoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `category`  VALUES ( "29","LPG 11KG","1","0");
INSERT INTO `category`  VALUES ( "30","LPG 2.5KG","1","0");
INSERT INTO `category`  VALUES ( "32","Santa Costume","0","0");
INSERT INTO `category`  VALUES ( "33","LPG 22KG","1","0");
INSERT INTO `category`  VALUES ( "34","LPG 7KG","0","0");
INSERT INTO `category`  VALUES ( "35","Clothes","0","0");


--
-- Tabel structure for table `city`
--
DROP TABLE  IF EXISTS `city`;
CREATE TABLE `city` (
  `CityID` int(11) NOT NULL AUTO_INCREMENT,
  `CityName` varchar(100) NOT NULL,
  `CityFee` int(11) NOT NULL,
  `CityDelete` int(5) NOT NULL,
  PRIMARY KEY (`CityID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `city`  VALUES ( "1","Binondo","5","0");
INSERT INTO `city`  VALUES ( "2","Ermita","10","0");
INSERT INTO `city`  VALUES ( "3","Intramuros","11","0");
INSERT INTO `city`  VALUES ( "4","Malate","15","0");
INSERT INTO `city`  VALUES ( "5","Paco","10","0");
INSERT INTO `city`  VALUES ( "6","Pandacan","20","0");
INSERT INTO `city`  VALUES ( "7","Port Area","0","0");
INSERT INTO `city`  VALUES ( "8","Quiapo","0","0");
INSERT INTO `city`  VALUES ( "9","Sampaloc","0","0");
INSERT INTO `city`  VALUES ( "10","San Miguel","0","0");
INSERT INTO `city`  VALUES ( "11","San Nicolas","0","0");
INSERT INTO `city`  VALUES ( "12","Santa Ana","0","0");
INSERT INTO `city`  VALUES ( "13","Santa Cruz","0","0");
INSERT INTO `city`  VALUES ( "14","Quezon Avenue","30","0");
INSERT INTO `city`  VALUES ( "15","asdasd","12","1");


--
-- Tabel structure for table `cms`
--
DROP TABLE  IF EXISTS `cms`;
CREATE TABLE `cms` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `footer` varchar(200) NOT NULL,
  `about` text NOT NULL,
  `contact_text` varchar(255) NOT NULL,
  `contact_address` varchar(200) NOT NULL,
  `slider1` varchar(200) NOT NULL,
  `slider2` varchar(200) NOT NULL,
  `home_title1` varchar(200) NOT NULL,
  `home_title2` varchar(200) NOT NULL,
  `home_title3` varchar(200) NOT NULL,
  `home_text1` varchar(125) NOT NULL,
  `home_text2` varchar(125) NOT NULL,
  `home_text3` varchar(125) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `cms`  VALUES ( "1","2016 LPGVILLE Trading. All Rights Reserved.
    
    
    ","If your server has activated support for PHP you do not need to do anything.

Just create some .php files, place them in your web directory, and the server will automatically parse them for you.

You do not need to compile anything or install any extra tools.

Because PHP is free, most web hosts offer PHP support.
    
    
    ","Please feel free to contact us, our customer service center is working for you 8-6.
    
    
    ","D.Tuazon Espana Manila Metro Manila, NCR Philippines
    
    
    ","slider2.jpg","slider3.jpg","WE LOVE OUR CUSTOMERS
    
    
    ","BEST PRICES
    
    
    ","100% SATISFACTION GUARANTEED
    
    
    ","We are known to provide best possible service ever.","One of the fair and affordable lpg retailer and wholesaler.","Free returns on everything.");


--
-- Tabel structure for table `damaged_reason`
--
DROP TABLE  IF EXISTS `damaged_reason`;
CREATE TABLE `damaged_reason` (
  `ReasonID` int(11) NOT NULL AUTO_INCREMENT,
  `ReasonName` varchar(50) NOT NULL,
  `ReasonDelete` int(5) NOT NULL,
  PRIMARY KEY (`ReasonID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `damaged_reason`  VALUES ( "1","Mismatch","0");
INSERT INTO `damaged_reason`  VALUES ( "2","Defective","0");
INSERT INTO `damaged_reason`  VALUES ( "3","Not Working Well","0");
INSERT INTO `damaged_reason`  VALUES ( "4","Tampered Seal","0");
INSERT INTO `damaged_reason`  VALUES ( "5","Tae Ni Roman","1");
INSERT INTO `damaged_reason`  VALUES ( "6","Incompatible","0");
INSERT INTO `damaged_reason`  VALUES ( "7","Sign Of Leakage","0");


--
-- Tabel structure for table `discount`
--
DROP TABLE  IF EXISTS `discount`;
CREATE TABLE `discount` (
  `DiscountID` int(11) NOT NULL AUTO_INCREMENT,
  `DiscountName` varchar(30) NOT NULL,
  `DiscountValue` int(11) NOT NULL,
  `DiscountDelete` int(5) NOT NULL,
  PRIMARY KEY (`DiscountID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `discount`  VALUES ( "1","Regular","10","0");
INSERT INTO `discount`  VALUES ( "2","Senior Citizen","20","0");
INSERT INTO `discount`  VALUES ( "3","None","0","0");
INSERT INTO `discount`  VALUES ( "5","Student","20","0");
INSERT INTO `discount`  VALUES ( "6","Exclusive","25","0");
INSERT INTO `discount`  VALUES ( "7","Tae mo roman ni migue","233","1");


--
-- Tabel structure for table `feedback`
--
DROP TABLE  IF EXISTS `feedback`;
CREATE TABLE `feedback` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Fullname` varchar(100) NOT NULL,
  `Email` varchar(120) NOT NULL,
  `Message` varchar(255) NOT NULL,
  `DateCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `feedback`  VALUES ( "1","James Harder","jameshardern@gmail.com","Your site is stunning and easy to use.","2017-03-09 13:57:16");
INSERT INTO `feedback`  VALUES ( "2","Fritz Tuna","fritz_tuna@gmail.com","Nice setup and good job Diego.","2017-03-09 14:01:41");


--
-- Tabel structure for table `inventorylog`
--
DROP TABLE  IF EXISTS `inventorylog`;
CREATE TABLE `inventorylog` (
  `InventoryLogID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductID` varchar(30) NOT NULL,
  `TotalReceivedPO` int(11) NOT NULL,
  `TotalDamaged` int(11) NOT NULL,
  `TotalStockSold` int(11) NOT NULL,
  `TotalSales` bigint(11) NOT NULL,
  `TotalStock` int(11) NOT NULL,
  `DateCreated` date NOT NULL,
  `CreatedBy` varchar(30) NOT NULL,
  PRIMARY KEY (`InventoryLogID`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

INSERT INTO `inventorylog`  VALUES ( "25","PROD-43-0","6","1","19","16615","6","2017-02-25","SUPERADMIN");
INSERT INTO `inventorylog`  VALUES ( "26","PROD-69-1","45","0","17","8160","0","2017-02-25","SUPERADMIN");
INSERT INTO `inventorylog`  VALUES ( "27","PROD-66-2","0","0","0","0","0","2017-02-25","SUPERADMIN");
INSERT INTO `inventorylog`  VALUES ( "28","PROD-68-3","71","0","29","14950","0","2017-02-25","SUPERADMIN");
INSERT INTO `inventorylog`  VALUES ( "29","PROD-92-4","60","0","22","11319","0","2017-02-25","SUPERADMIN");
INSERT INTO `inventorylog`  VALUES ( "30","PROD-73-5","4","0","46","27830","12","2017-03-07","SUPERADMIN");
INSERT INTO `inventorylog`  VALUES ( "31","PROD-65-6","4","0","43","20640","14","2017-03-07","SUPERADMIN");
INSERT INTO `inventorylog`  VALUES ( "32","PROD-73-7","8","0","37","19980","11","2017-03-07","SUPERADMIN");


--
-- Tabel structure for table `limit_orders`
--
DROP TABLE  IF EXISTS `limit_orders`;
CREATE TABLE `limit_orders` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Value` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `limit_orders`  VALUES ( "1","No. of orders allowed (Not paid)","2");


--
-- Tabel structure for table `order_setting`
--
DROP TABLE  IF EXISTS `order_setting`;
CREATE TABLE `order_setting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DeliveryFee` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `order_setting`  VALUES ( "1","50");


--
-- Tabel structure for table `orders`
--
DROP TABLE  IF EXISTS `orders`;
CREATE TABLE `orders` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `OrdersID` varchar(30) NOT NULL,
  `ProductID` varchar(20) NOT NULL,
  `OrderedQty` int(11) NOT NULL,
  `Price` bigint(11) NOT NULL,
  `TotalPrice` bigint(11) NOT NULL,
  `DeliveredQty` int(11) NOT NULL,
  `PickedupQty` int(11) NOT NULL,
  `ReturnedQty` int(11) NOT NULL,
  `DeliveryStatus` varchar(30) NOT NULL,
  `PickedupStatus` varchar(40) NOT NULL,
  `PaymentStatus` varchar(30) NOT NULL,
  `WalkinQty` int(11) NOT NULL,
  `WalkinStatus` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=latin1;

INSERT INTO `orders`  VALUES ( "176","ORD-48-0","PROD-65-6","1","480","480","0","0","0","Null","Null","Paid","1","Completed");
INSERT INTO `orders`  VALUES ( "177","ORD-48-0","PROD-43-0","5","923","4615","0","0","0","Null","Null","Paid","5","Completed");
INSERT INTO `orders`  VALUES ( "178","ORD-36-1","PROD-73-7","11","540","5940","0","5","0","Null","Partially Pickedup","Paid","0","Null");
INSERT INTO `orders`  VALUES ( "179","ORD-36-1","PROD-65-6","12","480","5760","0","5","0","Null","Partially Pickedup","Paid","0","Null");
INSERT INTO `orders`  VALUES ( "180","ORD-36-1","PROD-73-5","13","605","7865","0","5","0","Null","Partially Pickedup","Paid","0","Null");
INSERT INTO `orders`  VALUES ( "181","ORD-79-2","PROD-73-7","10","540","5400","6","0","0","Partially Delivered","Null","Paid","0","Null");
INSERT INTO `orders`  VALUES ( "182","ORD-79-2","PROD-65-6","11","480","5280","8","0","0","Partially Delivered","Null","Paid","0","Null");
INSERT INTO `orders`  VALUES ( "183","ORD-79-2","PROD-73-5","12","605","7260","7","0","0","Partially Delivered","Null","Paid","0","Null");
INSERT INTO `orders`  VALUES ( "184","ORD-79-2","PROD-43-0","13","923","11999","5","0","0","Partially Delivered","Null","Paid","0","Null");


--
-- Tabel structure for table `orders_total`
--
DROP TABLE  IF EXISTS `orders_total`;
CREATE TABLE `orders_total` (
  `OrdersID` varchar(20) NOT NULL,
  `SubAmount` bigint(11) NOT NULL,
  `DeliveryCharge` int(11) NOT NULL,
  `DiscountedAmount` int(11) NOT NULL,
  `GrandAmount` bigint(11) NOT NULL,
  `AmountPayable` bigint(11) NOT NULL,
  `AmountChange` double NOT NULL,
  `BillingID` varchar(30) NOT NULL,
  `PaymentType` varchar(30) NOT NULL,
  `AmountPaid` bigint(11) NOT NULL,
  `DiscountID` varchar(30) NOT NULL,
  `DateOrdered` date NOT NULL,
  `OrderStatus` varchar(100) NOT NULL,
  `PaymentStatus` varchar(20) NOT NULL,
  `DeliveryStatus` varchar(20) NOT NULL,
  `PickedupStatus` varchar(40) NOT NULL,
  `TransactionType` varchar(20) NOT NULL,
  `PreparedBy` varchar(30) NOT NULL,
  `OrderBy` varchar(30) NOT NULL,
  `OrderType` varchar(30) NOT NULL,
  `ReturnedStatus` int(5) NOT NULL,
  `WalkinStatus` varchar(50) NOT NULL,
  `OrdersDelete` int(5) NOT NULL,
  `OrderDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DateFinished` varchar(50) NOT NULL,
  PRIMARY KEY (`OrdersID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `orders_total`  VALUES ( "ORD-36-1","19565","0","0","19565","19565","0","BILL-57-1","Bank Deposit","19565","3","2017-03-09","Being Prepared","Paid","Null","Partially Pickedup","Pickup","SUPERADMIN","USER-95-3","Online","0","Null","0","2017-03-09 15:12:15","Null");
INSERT INTO `orders_total`  VALUES ( "ORD-48-0","5095","0","510","5095","4586","14.5","BILL-25-0","Cash","4600","1","2017-03-09","Completed","Paid","Null","Null","Walkin","SUPERADMIN","BILL-25-0","Walkin","0","Completed","0","2017-03-09 15:04:42","Null");
INSERT INTO `orders_total`  VALUES ( "ORD-79-2","29939","920","0","30859","30859","141","BILL-18-2","COD","31000","3","2017-03-09","Being Prepared","Paid","Partially Delivered","Null","Delivery","SUPERADMIN","USER-95-3","Online","0","Null","0","2017-03-09 17:38:13","Null");


--
-- Tabel structure for table `payment`
--
DROP TABLE  IF EXISTS `payment`;
CREATE TABLE `payment` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `OrdersID` varchar(30) NOT NULL,
  `Amount` bigint(11) NOT NULL,
  `PaymentType` varchar(30) NOT NULL,
  `DatePaid` date NOT NULL,
  `ReceivedBy` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO `payment`  VALUES ( "24","ORD-62-0","16000","Cash","2017-03-08","SUPERADMIN");
INSERT INTO `payment`  VALUES ( "25","ORD-84-1","3415","Cash","2017-03-08","SUPERADMIN");
INSERT INTO `payment`  VALUES ( "26","ORD-48-0","4600","Cash","2017-03-09","SUPERADMIN");
INSERT INTO `payment`  VALUES ( "27","ORD-36-1","19565","Bank Deposit","2017-03-09","SUPERADMIN");
INSERT INTO `payment`  VALUES ( "28","ORD-79-2","31000","Cash","2017-03-09","SUPERADMIN");


--
-- Tabel structure for table `payment_slip`
--
DROP TABLE  IF EXISTS `payment_slip`;
CREATE TABLE `payment_slip` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `OrdersID` varchar(30) NOT NULL,
  `DepositSlip` varchar(255) NOT NULL,
  `DatePaid` date NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `payment_slip`  VALUES ( "3","ORD-86-1","854232.jpg","2017-02-25");
INSERT INTO `payment_slip`  VALUES ( "4","ORD-46-2","738308.jpg","2017-02-25");
INSERT INTO `payment_slip`  VALUES ( "5","ORD-48-3","551131.jpg","2017-02-27");
INSERT INTO `payment_slip`  VALUES ( "6","ORD-36-1","447595.jpg","2017-03-09");


--
-- Tabel structure for table `po`
--
DROP TABLE  IF EXISTS `po`;
CREATE TABLE `po` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `POID` varchar(30) NOT NULL,
  `ProductID` varchar(20) NOT NULL,
  `RequestedQty` int(11) NOT NULL,
  `Price` bigint(11) NOT NULL,
  `TotalPrice` bigint(11) NOT NULL,
  `ReceivedQty` int(11) NOT NULL,
  `ReturnedQty` int(11) NOT NULL,
  `POStatus` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

INSERT INTO `po`  VALUES ( "25","PO-72-0","PROD-68-3","11","380","4180","11","0","Completed");
INSERT INTO `po`  VALUES ( "26","PO-72-0","PROD-69-1","15","400","6000","15","0","Completed");
INSERT INTO `po`  VALUES ( "27","PO-72-0","PROD-92-4","10","410","4100","10","0","Completed");
INSERT INTO `po`  VALUES ( "28","PO-40-1","PROD-68-3","60","420","25200","60","0","Completed");
INSERT INTO `po`  VALUES ( "29","PO-40-1","PROD-69-1","30","400","12000","30","0","Completed");
INSERT INTO `po`  VALUES ( "30","PO-40-1","PROD-92-4","50","400","20000","50","0","Completed");
INSERT INTO `po`  VALUES ( "31","PO-78-2","PROD-73-7","5","450","2250","5","3","Completed");
INSERT INTO `po`  VALUES ( "32","PO-78-2","PROD-65-6","4","400","1600","4","0","Completed");
INSERT INTO `po`  VALUES ( "33","PO-78-2","PROD-73-5","4","550","2200","4","0","Completed");
INSERT INTO `po`  VALUES ( "34","PO-78-2","PROD-43-0","5","700","3500","5","0","Completed");
INSERT INTO `po`  VALUES ( "35","PO-82-3","PROD-73-7","6","450","2700","0","0","Pending");
INSERT INTO `po`  VALUES ( "36","PO-10-4","PROD-65-6","8","400","3200","0","0","Pending");
INSERT INTO `po`  VALUES ( "37","PO-21-5","PROD-73-5","9","550","4950","0","0","Pending");
INSERT INTO `po`  VALUES ( "38","PO-46-3","PROD-73-7","6","450","2700","0","0","Pending");
INSERT INTO `po`  VALUES ( "39","PO-46-3","PROD-65-6","7","400","2800","0","0","Pending");
INSERT INTO `po`  VALUES ( "40","PO-46-3","PROD-73-5","8","550","4400","0","0","Pending");
INSERT INTO `po`  VALUES ( "41","PO-41-4","PROD-43-0","8","710","5680","0","0","Pending");
INSERT INTO `po`  VALUES ( "42","PO-41-4","PROD-73-7","4","450","1800","0","0","Pending");
INSERT INTO `po`  VALUES ( "43","PO-41-4","PROD-65-6","3","400","1200","0","0","Pending");
INSERT INTO `po`  VALUES ( "44","PO-41-4","PROD-73-5","5","550","2750","0","0","Pending");


--
-- Tabel structure for table `po_cart`
--
DROP TABLE  IF EXISTS `po_cart`;
CREATE TABLE `po_cart` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductID` varchar(20) NOT NULL,
  `Qty` int(11) NOT NULL,
  `Price` bigint(11) NOT NULL,
  `TotalPrice` bigint(11) NOT NULL,
  `SupplierID` varchar(20) NOT NULL,
  `UserID` varchar(20) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `po_total`
--
DROP TABLE  IF EXISTS `po_total`;
CREATE TABLE `po_total` (
  `POID` varchar(30) NOT NULL,
  `SupplierID` varchar(20) NOT NULL,
  `TotalAmount` bigint(11) NOT NULL,
  `DeliveryDate` date NOT NULL,
  `DateCreated` date NOT NULL,
  `Status` varchar(20) NOT NULL,
  `UserID` varchar(30) NOT NULL,
  `OrdersID` varchar(30) NOT NULL,
  PRIMARY KEY (`POID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `po_total`  VALUES ( "PO-40-1","SUP-94-0","57200","2017-03-01","2017-02-28","Completed","SUPERADMIN","Null");
INSERT INTO `po_total`  VALUES ( "PO-41-4","SUP-22-4","11430","2017-03-09","2017-03-09","Pending","SUPERADMIN","ORD-79-2");
INSERT INTO `po_total`  VALUES ( "PO-46-3","SUP-22-4","9900","2017-03-09","2017-03-09","Pending","SUPERADMIN","ORD-36-1");
INSERT INTO `po_total`  VALUES ( "PO-72-0","SUP-94-0","14280","2017-03-04","2017-02-25","Completed","SUPERADMIN","Null");
INSERT INTO `po_total`  VALUES ( "PO-78-2","SUP-47-2","5700","2017-03-08","2017-03-08","Completed","SUPERADMIN","Null");


--
-- Tabel structure for table `product`
--
DROP TABLE  IF EXISTS `product`;
CREATE TABLE `product` (
  `ProductID` varchar(20) NOT NULL,
  `CategoryID` varchar(20) NOT NULL,
  `QtyID` varchar(20) NOT NULL,
  `ProdName` varchar(100) NOT NULL,
  `Stock` int(11) NOT NULL,
  `CostPrice` bigint(11) NOT NULL,
  `MarkUp` int(11) NOT NULL,
  `RetailPrice` bigint(11) NOT NULL,
  `Threshold` int(11) NOT NULL,
  `ProdDetail` text NOT NULL,
  `ProdImage` varchar(100) NOT NULL,
  `ProdStatus` varchar(10) NOT NULL,
  `DateAdded` date NOT NULL,
  `ProductDelete` int(5) NOT NULL,
  PRIMARY KEY (`ProductID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `product`  VALUES ( "PROD-43-0","32","1","Red Jumpsuit","0","710","30","923","8","Red and floppy.     ","432460.jpg","Active","2017-02-25","0");
INSERT INTO `product`  VALUES ( "PROD-65-6","35","1","Gray Sweater","0","400","20","480","10","Comfortable and cool,","478476.jpg","Active","2017-03-07","0");
INSERT INTO `product`  VALUES ( "PROD-66-2","29","1","Solane","0","430","30","559","11","11 kilogram gas        ","383698.jpg","Active","2017-02-25","0");
INSERT INTO `product`  VALUES ( "PROD-68-3","29","1","Totalgaz","40","420","30","546","10","11 kilogram gas","941931.jpg","Active","2017-02-25","0");
INSERT INTO `product`  VALUES ( "PROD-69-1","29","1","Gasul","20","400","20","480","10","11 kilogram lpg ","295358.jpg","Active","2017-02-25","0");
INSERT INTO `product`  VALUES ( "PROD-73-5","35","1","Pink Polo","0","550","10","605","10","Pinky","22772.jpg","Active","2017-03-07","0");
INSERT INTO `product`  VALUES ( "PROD-73-7","35","1","Black Jacket","0","450","20","540","10","LOL","800893.jpg","Active","2017-03-07","0");
INSERT INTO `product`  VALUES ( "PROD-92-4","29","1","Petronas","30","400","27","508","8","11 kilogram gas","866438.jpg","Active","2017-02-25","0");


--
-- Tabel structure for table `quantity_type`
--
DROP TABLE  IF EXISTS `quantity_type`;
CREATE TABLE `quantity_type` (
  `QtyID` int(11) NOT NULL AUTO_INCREMENT,
  `QtyName` varchar(50) NOT NULL,
  `QtyDelete` int(5) NOT NULL,
  PRIMARY KEY (`QtyID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `quantity_type`  VALUES ( "1","Piece","0");
INSERT INTO `quantity_type`  VALUES ( "2","Box","0");
INSERT INTO `quantity_type`  VALUES ( "3","Set","0");


--
-- Tabel structure for table `returned_orders`
--
DROP TABLE  IF EXISTS `returned_orders`;
CREATE TABLE `returned_orders` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `OrdersID` varchar(30) NOT NULL,
  `ProductID` varchar(30) NOT NULL,
  `Qty` int(11) NOT NULL,
  `ReasonID` varchar(30) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `DateAdded` date NOT NULL,
  `Received` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `returned_orders2`
--
DROP TABLE  IF EXISTS `returned_orders2`;
CREATE TABLE `returned_orders2` (
  `OrdersID` varchar(30) NOT NULL,
  `DateAdded` date NOT NULL,
  PRIMARY KEY (`OrdersID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `returned_po`
--
DROP TABLE  IF EXISTS `returned_po`;
CREATE TABLE `returned_po` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `POID` varchar(30) NOT NULL,
  `ProductID` varchar(30) NOT NULL,
  `Qty` int(11) NOT NULL,
  `ReasonID` varchar(30) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `DateAdded` date NOT NULL,
  `AddedBy` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `returned_po`  VALUES ( "6","PO-78-2","PROD-73-7","3","1","3","Pending","2017-03-08","SUPERADMIN");


--
-- Tabel structure for table `returned_po2`
--
DROP TABLE  IF EXISTS `returned_po2`;
CREATE TABLE `returned_po2` (
  `POID` varchar(30) NOT NULL,
  `SupplierID` varchar(30) NOT NULL,
  `DateAdded` date NOT NULL,
  PRIMARY KEY (`POID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `returned_po2`  VALUES ( "PO-78-2","SUP-47-2","2017-03-08");


--
-- Tabel structure for table `sales_cart`
--
DROP TABLE  IF EXISTS `sales_cart`;
CREATE TABLE `sales_cart` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductID` varchar(30) NOT NULL,
  `Price` bigint(11) NOT NULL,
  `Qty` int(11) NOT NULL,
  `TotalPrice` bigint(11) NOT NULL,
  `UserID` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `supplier`
--
DROP TABLE  IF EXISTS `supplier`;
CREATE TABLE `supplier` (
  `SupplierID` varchar(20) NOT NULL,
  `SupplierName` varchar(60) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Contact` varchar(30) NOT NULL,
  `SupplierStatus` varchar(10) NOT NULL,
  `SupplierDelete` int(5) NOT NULL,
  PRIMARY KEY (`SupplierID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `supplier`  VALUES ( "SUP-22-4","Bench","benchph@gmail.com","924 1243","Active","0");
INSERT INTO `supplier`  VALUES ( "SUP-40-1","Shell Philippines","shell-ph@gmail.com","432 5343","Active","0");
INSERT INTO `supplier`  VALUES ( "SUP-47-2","Penshoppe","pensoppe@gmail.com","943 4324","Active","0");
INSERT INTO `supplier`  VALUES ( "SUP-77-3","Toy Kingdom","toykingdom@gmail.com","943 5343","Active","0");
INSERT INTO `supplier`  VALUES ( "SUP-94-0","Petron Philippines","petron@gmail.com","932 3234","Active","0");


--
-- Tabel structure for table `supplier_product`
--
DROP TABLE  IF EXISTS `supplier_product`;
CREATE TABLE `supplier_product` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SupplierID` varchar(30) NOT NULL,
  `ProductID` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `supplier_product`  VALUES ( "3","SUP-47-2","PROD-73-5");
INSERT INTO `supplier_product`  VALUES ( "4","SUP-47-2","PROD-43-0");
INSERT INTO `supplier_product`  VALUES ( "5","SUP-94-0","PROD-69-1");
INSERT INTO `supplier_product`  VALUES ( "6","SUP-94-0","PROD-92-4");
INSERT INTO `supplier_product`  VALUES ( "7","SUP-94-0","PROD-66-2");
INSERT INTO `supplier_product`  VALUES ( "8","SUP-94-0","PROD-68-3");
INSERT INTO `supplier_product`  VALUES ( "9","SUP-40-1","PROD-69-1");
INSERT INTO `supplier_product`  VALUES ( "10","SUP-40-1","PROD-92-4");
INSERT INTO `supplier_product`  VALUES ( "11","SUP-40-1","PROD-66-2");
INSERT INTO `supplier_product`  VALUES ( "12","SUP-40-1","PROD-68-3");
INSERT INTO `supplier_product`  VALUES ( "13","SUP-47-2","PROD-73-7");
INSERT INTO `supplier_product`  VALUES ( "14","SUP-47-2","PROD-65-6");
INSERT INTO `supplier_product`  VALUES ( "15","SUP-22-4","PROD-73-7");
INSERT INTO `supplier_product`  VALUES ( "16","SUP-22-4","PROD-65-6");
INSERT INTO `supplier_product`  VALUES ( "17","SUP-22-4","PROD-73-5");
INSERT INTO `supplier_product`  VALUES ( "18","SUP-22-4","PROD-43-0");


--
-- Tabel structure for table `tanks`
--
DROP TABLE  IF EXISTS `tanks`;
CREATE TABLE `tanks` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `OrdersID` varchar(30) NOT NULL,
  `ProductID` varchar(30) NOT NULL,
  `Qty` int(11) NOT NULL,
  `ReturnedQty` int(5) NOT NULL,
  `Status` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tanks_total`
--
DROP TABLE  IF EXISTS `tanks_total`;
CREATE TABLE `tanks_total` (
  `OrdersID` varchar(30) NOT NULL,
  `DateAdded` date NOT NULL,
  `Status` varchar(30) NOT NULL,
  PRIMARY KEY (`OrdersID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `temp_member`
--
DROP TABLE  IF EXISTS `temp_member`;
CREATE TABLE `temp_member` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `confirm_code` varchar(255) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Fullname` varchar(100) NOT NULL,
  `Contact` varchar(30) NOT NULL,
  `Address` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `temp_member`  VALUES ( "1","3771dfefa71bad3b19c4d34f862c2074","mikedantoni@gmail.com","password","Mike Dantoni","639065538209","Espana Manila");
INSERT INTO `temp_member`  VALUES ( "2","12fd69884e8248af9930517c30ffecff","mike@gmail.com","password","Mike Dantoni","639065538209","Quezon City");


--
-- Tabel structure for table `trail`
--
DROP TABLE  IF EXISTS `trail`;
CREATE TABLE `trail` (
  `TrailID` int(11) NOT NULL AUTO_INCREMENT,
  `ID` varchar(20) NOT NULL,
  `UserID` varchar(20) NOT NULL,
  `Message` text NOT NULL,
  `DateCreated` date NOT NULL,
  PRIMARY KEY (`TrailID`)
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=latin1;

INSERT INTO `trail`  VALUES ( "211","PROD-43-0","SUPERADMIN","Added a new product (Red Jumpsuit).","2017-02-25");
INSERT INTO `trail`  VALUES ( "212","PROD-69-1","SUPERADMIN","Added a new product (Gasul).","2017-02-25");
INSERT INTO `trail`  VALUES ( "213","PROD-66-2","SUPERADMIN","Added a new product (Solane).","2017-02-25");
INSERT INTO `trail`  VALUES ( "214","PROD-68-3","SUPERADMIN","Added a new product (Totalgaz).","2017-02-25");
INSERT INTO `trail`  VALUES ( "215","PROD-92-4","SUPERADMIN","Added a new product (Petronas).","2017-02-25");
INSERT INTO `trail`  VALUES ( "216","PO-72-0","SUPERADMIN","Added a purchase order (PO-72-0).","2017-02-25");
INSERT INTO `trail`  VALUES ( "217","PO-40-1","SUPERADMIN","Added a purchase order (PO-40-1).","2017-02-28");
INSERT INTO `trail`  VALUES ( "218","bd","USER-884-5","Backed up the database.","2017-03-06");
INSERT INTO `trail`  VALUES ( "219","bd","SUPERADMIN","Backed up the database.","2017-03-06");
INSERT INTO `trail`  VALUES ( "220","bd","SUPERADMIN","Backed up the database.","2017-03-06");
INSERT INTO `trail`  VALUES ( "221","bd","SUPERADMIN","Backed up the database.","2017-03-06");
INSERT INTO `trail`  VALUES ( "222","bd","SUPERADMIN","Backed up the database.","2017-03-06");
INSERT INTO `trail`  VALUES ( "223","categoryid","SUPERADMIN","Added a new category type (LPG 22KG).","2017-03-07");
INSERT INTO `trail`  VALUES ( "224","categoryid","SUPERADMIN","Added a new category type (LPG 7KG).","2017-03-07");
INSERT INTO `trail`  VALUES ( "225","categoryid","SUPERADMIN","Added a new category type (Clothes).","2017-03-07");
INSERT INTO `trail`  VALUES ( "226","PROD-73-5","SUPERADMIN","Added a new product (Pink Polo).","2017-03-07");
INSERT INTO `trail`  VALUES ( "227","PROD-65-6","SUPERADMIN","Added a new product (Gray Sweater).","2017-03-07");
INSERT INTO `trail`  VALUES ( "228","PROD-73-7","SUPERADMIN","Added a new product (Black Jacket).","2017-03-07");
INSERT INTO `trail`  VALUES ( "229","PO-78-2","SUPERADMIN","Added a purchase order (PO-78-2).","2017-03-08");
INSERT INTO `trail`  VALUES ( "230","PROD-65-6","SUPERADMIN","Added 1 stock. (Gray Sweater)","2017-03-09");
INSERT INTO `trail`  VALUES ( "231","SUP-22-4","SUPERADMIN","Added a supplier (Bench).","2017-03-09");
INSERT INTO `trail`  VALUES ( "232","PROD-73-7","SUPERADMIN","Added 5 stock. (Black Jacket)","2017-03-09");
INSERT INTO `trail`  VALUES ( "233","PROD-65-6","SUPERADMIN","Added 5 stock. (Gray Sweater)","2017-03-09");
INSERT INTO `trail`  VALUES ( "234","PROD-73-5","SUPERADMIN","Added 5 stock. (Pink Polo)","2017-03-09");
INSERT INTO `trail`  VALUES ( "235","PROD-43-0","SUPERADMIN","Added 5 stock. (Red Jumpsuit)","2017-03-09");
INSERT INTO `trail`  VALUES ( "236","PROD-73-7","SUPERADMIN","Added 6 stock. (Black Jacket)","2017-03-09");
INSERT INTO `trail`  VALUES ( "237","PROD-73-5","SUPERADMIN","Added 7 stock. (Pink Polo)","2017-03-09");
INSERT INTO `trail`  VALUES ( "238","PROD-65-6","SUPERADMIN","Added 8 stock. (Gray Sweater)","2017-03-09");


--
-- Tabel structure for table `transaction_setting`
--
DROP TABLE  IF EXISTS `transaction_setting`;
CREATE TABLE `transaction_setting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TransactionName` varchar(100) NOT NULL,
  `Status` int(5) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `transaction_setting`  VALUES ( "1","Pickup Order","1");
INSERT INTO `transaction_setting`  VALUES ( "2","Delivery Order","1");


--
-- Tabel structure for table `user`
--
DROP TABLE  IF EXISTS `user`;
CREATE TABLE `user` (
  `UserID` varchar(20) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `Role` varchar(15) NOT NULL,
  `UserStatus` varchar(10) NOT NULL,
  `DateAdded` date NOT NULL,
  `UserDelete` int(5) NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user`  VALUES ( "SUPERADMIN","admin","password","Superadmin","Active","2016-12-02","0");
INSERT INTO `user`  VALUES ( "USER-249-6","jenolabilles","password","Admin","Active","2017-02-08","1");
INSERT INTO `user`  VALUES ( "USER-528-4","aaronmayugba","password","Admin","Active","2017-02-08","0");
INSERT INTO `user`  VALUES ( "USER-884-5","jamesmalinao","jamesmalinao","Admin","Active","2017-02-08","0");
INSERT INTO `user`  VALUES ( "USER-95-3","fritz_tuna@gmail.com","password","User","Active","2017-02-25","0");


--
-- Tabel structure for table `user_access`
--
DROP TABLE  IF EXISTS `user_access`;
CREATE TABLE `user_access` (
  `UserID` varchar(30) NOT NULL,
  `Inventory` int(5) NOT NULL,
  `PO` int(5) NOT NULL,
  `Orders` int(5) NOT NULL,
  `Reports` int(5) NOT NULL,
  `Settings` int(5) NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user_access`  VALUES ( "SUPERADMIN","1","1","1","1","1");
INSERT INTO `user_access`  VALUES ( "USER-249-6","1","1","0","0","0");
INSERT INTO `user_access`  VALUES ( "USER-528-4","1","1","1","0","0");
INSERT INTO `user_access`  VALUES ( "USER-884-5","1","1","0","1","1");


--
-- Tabel structure for table `user_info`
--
DROP TABLE  IF EXISTS `user_info`;
CREATE TABLE `user_info` (
  `UserID` varchar(20) NOT NULL,
  `Fullname` varchar(100) NOT NULL,
  `Contact` varchar(50) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Address` varchar(150) NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user_info`  VALUES ( "SUPERADMIN","Superadmin","09065538209","arazasdiego@gmail.com","Grass Residences Tower 1 1619B Brgy. Sto. Cristo North Avenue Quezon City");
INSERT INTO `user_info`  VALUES ( "USER-528-4","Aaron Mayugba","09156934053","aaronmayugba@gmail.com","Quezon City");
INSERT INTO `user_info`  VALUES ( "USER-884-5","James Malinao","09242124955","james_malinao@gmail.com","Espana, Manila City");
INSERT INTO `user_info`  VALUES ( "USER-95-3","Fritz Tuna","639198240155","fritz_tuna@gmail.com","Caloocan, Metro Manila");


--
-- Tabel structure for table `vat`
--
DROP TABLE  IF EXISTS `vat`;
CREATE TABLE `vat` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Value` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `vat`  VALUES ( "1","VAT","12");


SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
